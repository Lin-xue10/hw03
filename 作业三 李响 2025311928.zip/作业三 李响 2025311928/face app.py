# app.py
import face_recognition
import streamlit as st
import numpy as np
from PIL import Image, ImageDraw
import os

def load_known_faces(known_faces_dir="known_faces"):
    known_encodings = []
    known_names = []
    if not os.path.exists(known_faces_dir):
        os.makedirs(known_faces_dir)
        return known_encodings, known_names
    for img_name in os.listdir(known_faces_dir):
        if img_name.lower().endswith(('png', 'jpg', 'jpeg')):
            img_path = os.path.join(known_faces_dir, img_name)
            image = face_recognition.load_image_file(img_path)
            face_encodings = face_recognition.face_encodings(image)
            if face_encodings:
                known_encodings.append(face_encodings[0])
                name = os.path.splitext(img_name)[0]
                known_names.append(name)
    return known_encodings, known_names

def detect_faces(image: Image.Image):
    img_np = np.array(image.convert("RGB"))
    face_locations = face_recognition.face_locations(img_np)
    return face_locations

def get_face_encodings(image: Image.Image, face_locations=None):
    img_np = np.array(image.convert("RGB"))
    encodings = face_recognition.face_encodings(img_np, face_locations)
    return encodings

def recognize_faces(unknown_encodings, known_encodings, known_names, tolerance=0.6):
    results = []
    for encoding in unknown_encodings:
        name = "Unknown"
        if known_encodings:
            matches = face_recognition.compare_faces(known_encodings, encoding, tolerance)
            face_distances = face_recognition.face_distance(known_encodings, encoding)
            if len(face_distances) > 0:
                best_match_idx = np.argmin(face_distances)
                if matches[best_match_idx]:
                    name = known_names[best_match_idx]
        results.append(name)
    return results

def draw_face_boxes(image: Image.Image, face_locations, names=None):
    draw = ImageDraw.Draw(image)
    for i, (top, right, bottom, left) in enumerate(face_locations):
        draw.rectangle([(left, top), (right, bottom)], outline="red", width=3)
        if names and i < len(names):
            name = names[i]
            text_bbox = draw.textbbox((left, bottom), name)
            draw.rectangle([(left, bottom), (text_bbox[2], text_bbox[3] + 6)], fill="red")
            draw.text((left, bottom), name, fill="white")
    return image

st.set_page_config(page_title="人脸识别系统", page_icon="👤", layout="wide")

@st.cache_resource
def load_faces():
    return load_known_faces()

known_encodings, known_names = load_faces()

st.title("👤 人脸识别检测系统")
st.markdown("### 基于 face_recognition + Streamlit 实现")
st.divider()

with st.sidebar:
    st.header("功能设置")
    option = st.radio("选择操作", ["人脸检测", "人脸识别"])
    st.divider()
    st.info(f"已加载人脸库：{len(known_names)} 人")
    if known_names:
        st.write(f"人脸列表：{', '.join(known_names)}")

img_source = st.radio("图片来源", ["本地上传"])
uploaded_img = None

if img_source == "本地上传":
    uploaded_file = st.file_uploader("上传图片", type=["png", "jpg", "jpeg"])
    if uploaded_file is not None:
        uploaded_img = Image.open(uploaded_file)

if uploaded_img is not None:
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("原始图片")
        st.image(uploaded_img, use_column_width=True)

    with col2:
        st.subheader("处理结果")
        face_locations = detect_faces(uploaded_img)
        if len(face_locations) == 0:
            st.error("未检测到人脸")
        else:
            face_encodings = get_face_encodings(uploaded_img, face_locations)
            if option == "人脸检测":
                result_img = draw_face_boxes(uploaded_img.copy(), face_locations)
                st.success(f"检测到 {len(face_locations)} 张人脸")
                st.image(result_img, use_column_width=True)
            else:
                if len(known_encodings) == 0:
                    st.warning("请先在 known_faces 文件夹中添加人脸图片")
                else:
                    names = recognize_faces(face_encodings, known_encodings, known_names)
                    result_img = draw_face_boxes(uploaded_img.copy(), face_locations, names)
                    st.success("识别完成！")
                    st.image(result_img, use_column_width=True)
                    with st.expander("查看人脸128维特征"):
                        for i, encode in enumerate(face_encodings):
                            st.write(f"人脸 {i+1} 特征编码：")
                            st.dataframe(encode.reshape(1, -1))
                            conda install -c conda-forge dlib -y